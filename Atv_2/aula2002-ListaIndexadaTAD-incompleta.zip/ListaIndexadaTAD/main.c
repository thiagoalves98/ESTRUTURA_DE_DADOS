#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int main()
{
    tLista minhaLista;

    IniciaLista(&minhaLista);

    InsereElemento(&minhaLista, 0, 1);
    InsereElemento(&minhaLista, 1, 2);
    InsereElemento(&minhaLista, 2, 3);
    InsereElemento(&minhaLista, 3, 4);
    InsereElemento(&minhaLista, 2, 5);
    InsereElemento(&minhaLista, 11, 6);


    int i;
    for(i = 0; i < TamanhoLista(&minhaLista); i++){
        printf("#%d: %d\n", i, ElementoLista(&minhaLista, i));
    }

    return 0;
}
